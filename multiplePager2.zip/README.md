"# medahereai" 
